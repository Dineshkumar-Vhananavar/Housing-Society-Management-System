create table admin(
	admin_id text primary key,
	admin_pwd text not null,
	admin_name text not null
);


insert into admin values('admin','admin','Deepak Vhananavar');

create table owner(
	owner_id serial primary key,
	owner_pwd text not null,
	owner_name text not null,
	owner_gender text not null,
	owner_dob date,
	owner_mobile text,
	owner_email text,
	owner_blg text,
	owner_flat_no text,
	owner_flat_type text
);

create table charges(
	one_bhk float,
	two_bhk float,
	three_bhk float,
	parking float,
	event_fund float,
	sink_fund float
);

insert into charges values(1000,1200,1600,500,0,0);

create table feedback(
	feedback_id serial primary key,
	feedback_date text not null,
	feedback_msg text not null,
	owner_id int references owner(owner_id)
);

create table owner_payable(
	amt_payable float,
	date_payable date,
	status text,
	owner_id int references owner(owner_id)
);






	


create table security(
	security_id text primary key,
	security_pwd text not null,
	security_name text not null
);

insert into security values('security','security','Bahaduur');





create table visitor(
	visitor_id serial primary key,
	visitor_name text not null,
	visitor_gender text not null,	
	visitor_mobile text,
	visit_to_blg text,
	visit_to_fno text,
	visit_to_Owner_name text
);